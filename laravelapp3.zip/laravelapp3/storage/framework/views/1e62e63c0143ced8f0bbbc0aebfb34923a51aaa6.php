<?php $__env->startSection('main'); ?>

<div id="siswa">
		<h2>Detil Siswa</h2>

	<table class="table table-striped">
				<tr>
					<th>NISN</th>
					<td><?php echo e($siswa->nisn); ?></td>
				</tr>
				<tr>
					<th>Nama</th>
					<td><?php echo e($siswa->nama_siswa); ?></td>
				</tr>
				<tr>
					<th>Tgl Lahir</th>
					<td><?php echo e($siswa->tgl_lahir); ?></td>
				</tr>
				<tr>
					<th>Kelamin</th>
					<td><?php echo e($siswa->jns_kelamin); ?></td>
					</tr>
				</tr>
				</table>
	</div>

	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('footer'); ?>
			<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>