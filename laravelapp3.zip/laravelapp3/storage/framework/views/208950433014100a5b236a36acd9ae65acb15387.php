<?php $__env->startSection('main'); ?>
<div id="homepage">
	<h2>Homepage</h2>
	<p>Selamat belajar larvel</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<div id="footer">
		<p>&copy; 2017 Laravel</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>