<?php $__env->startSection('main'); ?>

<div id="siswa">
		<h2>Siswa</h2>

<?php if(!empty($siswa_list)): ?>
	<table class="table">
		<thead>
			<tr>
				<th>NISN</th>
				<th>Nama</th>
				<th>Tgl Lahir</th>
				<th>Kelamin</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($siswa_list as $siswa): ?>
				<tr>
					<td><?php echo e($siswa->nisn); ?></td>
					<td><?php echo e($siswa->nama_siswa); ?></td>
					<td><?php echo e($siswa->tgl_lahir); ?></td>
					<td><?php echo e($siswa->jns_kelamin); ?></td>
					<td><?php echo e(link_to('siswa/'.$siswa->id, 'Detail', ['class' =>'btn btn-success btn-sm'] )); ?>

						<?php echo e(link_to('siswa/' . $siswa->id . '/edit', 'Edit', ['class' => 'btn btn-warning btn-sm'])); ?>

					</td>

				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php else: ?>
	<p>tidak ada siswa</p>
<?php endif; ?>

<div class="table-bottom">
	<div class="pull-left">
	<strong>Jumlah Siswa : <?php echo e($jumlah_siswa); ?></strong>
	</div>
	<div class="pull-right">
		Pagination
	</div>
</div>
<div class="bottom-nav">
	<div>
		<a href="siswa/create" class="btn btn-primary">Tambah Siswa</a>
	</div>
</div>
</div>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('footer'); ?>
			<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>