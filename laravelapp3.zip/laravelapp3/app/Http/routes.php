<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('halo', function () {
  return 'Halo, Hai';
});

    Route::get('/','PagesController@homepage'); 

	Route::get('about','PagesController@about');

	Route::get('siswa', 'SiswaController@index');

	Route::get('siswa/create', 'SiswaController@create');

    Route::get('siswa/{siswa}','SiswaController@show');

  	Route::post('siswa','SiswaController@store');

    Route::get('siswa/{siswa}/edit', 'SiswaController@edit');
    
    Route::patch('siswa/{siswa}', 'SiswaController@update');


	






/*
Route::get('sampledata', function() {
	DB::table('siswa')->insert([
    //
    [
    	'nisn' => '1004',
    	'nama_siswa' => 'ari yulianto',
    	'tgl_lahir' => '1999-10-11',
    	'jns_kelamin' => 'L',
    	'created_at' => '2016-03-10 19:10:14',
    	 'updated_at' => '2016-03-10 20:10:14'
    ],
    [
    	'nisn' => '1005',
    	'nama_siswa' => 'pada asdsa',
    	'tgl_lahir' => '1992-10-11',
    	'jns_kelamin' => 'P',
    	'created_at' => '2016-03-10 19:10:14',
    	 'updated_at' => '2016-03-10 20:10:14'
    ],
    [
    	'nisn' => '1006',
    	'nama_siswa' => 'sanang asdsa',
    	'tgl_lahir' => '1994-10-11',
    	'jns_kelamin' => 'P',
    	'created_at' => '2016-03-10 19:10:14',
    	 'updated_at' => '2016-03-10 20:10:14',
    ],
]);
});
*/


