<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;

use App\Http\Requests;
use App\Siswa;


class SiswaController extends Controller
{
    //
    public function index()
    {
    
	$siswa_list	= Siswa::all()->sortBy('tgl_lahir');
    $jumlah_siswa = $siswa_list->count();
	return view('siswa.index', compact('halaman','siswa_list','jumlah_siswa'));

    }

    public function create()
    {
        
    	return view ('siswa.create', compact('halaman'));
    }


    public function store (Request $request)
    {
    	$input = $request->all();
        Siswa::create($input);
        return redirect ('siswa');
    }

    public function show($id)
    {
        
        $siswa = Siswa::FindOrFail($id);
        return view ('siswa.show', compact('halaman','siswa'));

    }

    public function edit($id)
    {
        $siswa = Siswa::FindOrFail($id);
        return view ('siswa.edit', compact('siswa'));
    }
}
