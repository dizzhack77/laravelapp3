@extends ('template')

@section ('main')
	<div id="siswa">
	<h2>Tambah Siswa</h2>	

	<form action="{{ url('siswa') }}" method="POST">

		<input type="hidden" name="_token" value="{{ csrf_token() }}">
		
		<div class="form-group">
	<label for="nisn" class="control-label">NISN</label>
	<input type="text" name="nisn" id="nisn" class="form-control">
		</div>

		<div class="form-group">
	<label for="nama_siswa" class="control-label">Nama</label>
	<input type="text" name="nama_siswa" id="nama_siswa" class="form-control">
		</div>

<div class="form-group">
	<label for="tgl_lahir" class="control-label">tgl_lahir</label>
	<input name="tgl_lahir" id="tgl_lahir" type="date" class="form-control">
		</div>

		<div class="form-group">
	<label for="jns_kelamin" class="control-label">Jenis Kelamin</label>
		<div class="radio">
	<label><input name="jns_kelamin" type="radio" value="L" id="jns_kelamin"> Laki-Laki</label>
</div>
	<div class="radio">
	<label><input name="jns_kelamin" type="radio" value="P" id="jns_kelamin"> Perempuan</label>
	</div>
</div>

<div class="form-group">
	<input class="btn btn-primary form-control" type="submit" value="Tambah Siswa">
</div>
</form>
</div>
@stop

@section('footer')
	@include('footer')
@stop