@extends('template')

@section('main')

<div id="siswa">
		<h2>Detil Siswa</h2>

	<table class="table table-striped">
				<tr>
					<th>NISN</th>
					<td>{{ $siswa->nisn }}</td>
				</tr>
				<tr>
					<th>Nama</th>
					<td>{{  $siswa->nama_siswa }}</td>
				</tr>
				<tr>
					<th>Tgl Lahir</th>
					<td>{{ $siswa->tgl_lahir }}</td>
				</tr>
				<tr>
					<th>Kelamin</th>
					<td>{{ $siswa->jns_kelamin }}</td>
					</tr>
				</tr>
				</table>
	</div>

	@stop

	@section('footer')
			@include('footer')
			@stop