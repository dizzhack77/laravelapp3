<div id="footer">
	<p>&copy; 2017 Syarifudin</p>
</div>