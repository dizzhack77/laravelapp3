@extends('template')

@section('main')
		<div id="about">
			<h2>About</h2>
			<p>aplikasi <strong>Laravel</strong> dibuat latihan</p>
		</div>
		@stop

@section('footer')
@include('footer')
			@stop