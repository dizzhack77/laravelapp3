@extends ('template')

@section('main')
<div id="homepage">
	<h2>Homepage</h2>
	<p>Selamat belajar larvel</p>
</div>
@stop

@section('footer')
@include('footer')
@stop