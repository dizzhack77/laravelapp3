<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
<h1>Home page</h1>
</body>
</html>